﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace DictionaryTry
{
    class Program
    {
        static void Main(string[] args)
        {
            int N_of_Stu = 0;
            int N_of_Sco = 0;
            double dblOutPut = 0;

            string grade = "";
            Console.WriteLine("How many students do you have?");

            if (int.TryParse(ReadLine(), out N_of_Stu) == false)
            {
                Console.WriteLine("Please enter appropriate numeric value");
                Console.WriteLine("How many students do you have?");

                if (int.TryParse(ReadLine(), out N_of_Stu) == false)
                {

                    Console.WriteLine("Sorry you have not entered a positive numeric value");
                }
            }

            Console.WriteLine("Please enter the number of exams you administered to the students");

            if (int.TryParse(ReadLine(), out N_of_Sco) == false)
            {
                Console.WriteLine("Please enter appropriate numeric value");
                Console.WriteLine("Please enter the number of exams you administered to the students");

                if (int.TryParse(ReadLine(), out N_of_Sco) == false)
                {

                    Console.WriteLine("Sorry you have not entered appropriate value");
                }
            }


            Dictionary<int, double> Student = new Dictionary<int, double>();

            List<double> scores = new List<double>();

            Dictionary<int, string> Grade = new Dictionary<int, string>();

            for (int st = 0; st < N_of_Stu; st++)
            {
                for (int sc = 0; sc < N_of_Sco; sc++)
                {
                    string strInput;

                    WriteLine(" Enter score # {0} for student #{1}", sc + 1, st + 1);
                    strInput = ReadLine();


                    if (double.TryParse(strInput, out dblOutPut) == false)
                    {
                        WriteLine("Please enter valid numeric value");
                    }
                    scores.Add(dblOutPut);

                    scores.Sum();


                }


                if (scores.Sum() > 100 || scores.Sum() < 0)

                    grade = "Error";

                else if (scores.Sum() > 94)

                    grade = "A+";

                else if (scores.Sum() > 90)

                    grade = "A";

                else if (scores.Sum() > 85)

                    grade = "B+";

                else if (scores.Sum() > 80)

                    grade = "B";

                else if (scores.Sum() > 70)

                    grade = "C+";

                else if (scores.Sum() > 60)

                    grade = "C";

                else if (scores.Sum() > 30)

                    grade = "D";

                else

                    grade = "F";
                Student.Add(st + 1, scores.Sum());
                Grade.Add(st + 1, grade);
                scores.Clear();


            }

            WriteLine("Student Total Score");
            WriteLine("-------------------");

            foreach (KeyValuePair<int, double> k in Student)
            {

                WriteLine("Student Number: {0} \t Total Score: {1} ",
                    k.Key.ToString(), k.Value.ToString());

            }
            WriteLine();
            WriteLine();
            WriteLine("Student Grades");
            WriteLine("-------------------");

            foreach (KeyValuePair<int, string> L in Grade)
            {

                WriteLine("Student Number: {0} \t Grade: {1} ",
                    L.Key.ToString(), L.Value);

            }

            ReadKey();
        }

    }
}