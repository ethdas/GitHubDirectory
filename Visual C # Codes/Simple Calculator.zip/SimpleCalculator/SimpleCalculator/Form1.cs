﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
        double one;
        double Two;
        double Result;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtOne.Text, out one)==false )
                MessageBox.Show("Please enter a valid number");
            if (double.TryParse(txtTwo.Text, out Two)== false )
                MessageBox.Show("Please enter a valid number");
            Result = one + Two;
            lblResult.Text = Result.ToString();
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
           if (double.TryParse(txtOne.Text, out one)== false)
                 MessageBox.Show("Please enter a valid number");
           if (double.TryParse(txtTwo.Text, out Two)== false)
                MessageBox.Show("Please enter a valid number");
            Result = one-Two;
            lblResult.Text = Result.ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
           if (double.TryParse(txtOne.Text, out one) == false )
                MessageBox.Show("Please enter a valid number");
            if (double.TryParse(txtTwo.Text, out Two)== false)
                 MessageBox.Show("Please enter a valid number");
            Result = one / Two;
            lblResult.Text = Result.ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtOne.Text, out one) == false)
                MessageBox.Show("Please enter a valid number");
            if  (double.TryParse(txtTwo.Text, out Two)== false )
                MessageBox.Show("Please enter a valid number");

            Result = one * Two;
            lblResult.Text = Result.ToString();
        }
    }
}
