﻿/*
 * Program Name: Measurement Converter
 * Author: Daniel Neway
 * Course: CIS162AD
 * Lesson: 3 
 * Date : 09/01/2018
 * Purpose: To write a program that converts a value in inches to feet,yard,and miles 
 */

using System;
using static System.Console;


namespace Conversion
{
    class InchConversion
    {
        static void Main(string[] args)
        {
            //Define variables and constants used to convert between inch , yard and miles
            int inches = 126696;
            const double INCH_TO_FEET_CONVERTER = 0.08333333;
            const double INCH_TO_YARD_CONVERTER = 0.02777778;
            const double INCH_TO_MILES_CONVERTER = 1.57828e-5;

            //Formula to convert inch to feet or yard or miles
            double convertedToFeet = inches * INCH_TO_FEET_CONVERTER;
            double convertedToYard = inches * INCH_TO_YARD_CONVERTER;
            double convertedToMile = inches * INCH_TO_MILES_CONVERTER;

            //Displays inches to feet 
            WriteLine("     **************************************");
            WriteLine();
            WriteLine( " 126,696 Inches to Feet  = {0:n2}  feet" , convertedToFeet );
            WriteLine();
            WriteLine("     **************************************");
            ReadLine();

            //Displays inches to yard after you press Enter
            WriteLine("     **************************************");
            WriteLine();
            WriteLine(" 126,696 Inches to yard  = {0:n2}  yards", convertedToYard);
            WriteLine();
            WriteLine("     **************************************");
            ReadLine();

            //Displays inches to Mile after  you press Enter
            WriteLine("     **************************************");
            WriteLine();
            WriteLine(" 126,696 Inches to Miles  = {0:n2}  Miles", convertedToMile);
            WriteLine();
            WriteLine("     **************************************");
            ReadLine();
            

        }
    }
}
