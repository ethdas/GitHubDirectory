﻿/*
 * Name : Daniel Neway 
 * Class: CIS 162AD
 * Lesson : 7
 * Title: calculates a student's GPA.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace GPA_CalculatorApp
{
    class StudentGPA
    {
        static void Main(string[] args)
        {

            string inputValue = "";
            int counter = 0;
            double sum = 0;
            double point = 0;
            double gpa;

            WriteLine(" Please enter your grades here ['A' , 'B' , 'C', 'D' , or 'F']  ");
            WriteLine("As soon as you are done entering write (X) to exit");

            inputValue = ReadLine();// Priming read
            while (inputValue != "X")
            {
                if (inputValue == "A")
                    point = 4;
                else if (inputValue == "B")
                    point = 3;
                else if (inputValue == "C")
                    point = 2;
                else if (inputValue == "D")
                    point = 1;
                else if (inputValue == "F")
                    point = 0;
                else
                    WriteLine(" you have entered an inappropriate value. \nPlease enter grade as per instruction: ['A' , 'B' , 'C', 'D' , or 'F']");

                counter++;
                sum += point;
                Write(" Enter More Grade or (X) to exit ");
                WriteLine();
                inputValue = ReadLine();

            }
            gpa = (sum / (double)counter);

            Write("your Total GPA is  : " + gpa.ToString("N2"));

            ReadKey();

        }
    }
}
