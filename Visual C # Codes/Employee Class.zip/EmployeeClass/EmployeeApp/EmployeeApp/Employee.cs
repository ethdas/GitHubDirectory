﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeApp
{
    class Employee
    {
        private string firstName;
        private string lastName;
        private double rateOfPay;
        private double hoursWorked;
        private string jobTitle;
        private int hireDate;


        // constructors

        public Employee()
        {

        }

        public Employee(string fName, string lName)
        {
            firstName = fName;
            lastName = lName;
        }


        public Employee(string fName , string lName ,double payRate , int hiredOn)
        {
            firstName = fName;
            lastName = lName;
            rateOfPay = payRate;
            hireDate = hiredOn;

        }

        public Employee(string fName, string lName, double payRate , double hours , string jTitle , int dateHired )
        {
            firstName = fName;
            lastName = lName;
            rateOfPay = payRate;
            hoursWorked = hours;
            jobTitle = jTitle;
            hireDate = dateHired;
        }

        // Properties

        public string FirstName
        {
            get{
                return firstName;
            }
            set {
                lastName = value;
                    }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                lastName = value;
            }

        }
        public double RateOfPay
        {
            get
            {
                return rateOfPay;
            }
            set
            {
                rateOfPay = value;
            }
        }

        public double HoursWorked
        {
            get
            {
                return hoursWorked;
            }
             set
            {
                hoursWorked = value;
            }
        }
        public string JobTitle
        {
            get
            {
                return jobTitle;
            }
            set
            {
                jobTitle = value;
            }
        }
        public int HireDate
        {
            get
            {
                return hireDate;
            }
            set
            {
                hireDate = value;
            }
        }

        // methods

        public string FullName()
        {
            return firstName + " " + lastName;
        }

        
        public double CalculateGrossPay()
        {
            return rateOfPay * hoursWorked;
        }

    }
}
