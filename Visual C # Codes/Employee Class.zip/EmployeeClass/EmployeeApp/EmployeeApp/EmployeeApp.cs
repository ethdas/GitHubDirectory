﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace EmployeeApp
{
    class EmployeeApp
    {
        static void Main(string[] args)
        {

            Employee employee_1 = new Employee("James" , "Wagner", 18.15, 40, "Machinist" , 20150913);
           WriteLine("Full Name : " + employee_1.FullName());
           WriteLine("Gross Pay in US Dollars :" + employee_1.CalculateGrossPay() + "$");
            ReadKey();
            WriteLine();
            WriteLine();


            Employee employee_2 = new Employee("Kathy", "Brown", 15.22, 20140217);
            
            WriteLine("Full Name : " + employee_2.FullName());
            WriteLine("You entered :" + AskForJobTitle("title"));
            employee_2.HoursWorked = AskForHrsWorked(0);
            WriteLine("Gross Pay in US Dollars :" + employee_2.CalculateGrossPay() + "$");
            
            ReadKey();

        }

        static int AskForHrsWorked ( int hrs)
        {
            string inValue;
            int hrswrkd;
            Write(" please enter number of hours worked for the above listed Name: " );
            inValue = ReadLine();
            hrswrkd = int.Parse(inValue);
            return hrswrkd;
        }

        static string AskForJobTitle(string ttle)
        {
            string inValue;
            WriteLine(" Enter Job Title here:");
            inValue = ReadLine();
            
            return inValue;
               
        }
    }
}
