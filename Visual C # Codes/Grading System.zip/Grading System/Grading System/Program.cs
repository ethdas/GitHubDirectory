﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console
    ;
namespace StudentsGradeSystem
{
    class Program
    {
        static void Main(string[] args)
        {
           
            int intStudents, intScores;

            intStudents = HowManyStudent();
            intScores = HowManyScores();

            double[,] gradeArray = new double[intStudents, intScores];
           
            CalcTotal_G(gradeArray);                      
            
            ReadKey();
            
        }

        public static int HowManyStudent ()
        {
            string strStudents;
            int intStudents;


            Write(" How many students do you have?  ");
            strStudents = " " + ReadLine();

            if (int.TryParse(strStudents, out intStudents) == false)
            {
                WriteLine("Please enter appropriate numeric value ");

                Write(" How many students do you have?  ");
                strStudents = " " + ReadLine();

                if (int.TryParse(strStudents, out intStudents) == false)
                {
                    WriteLine("Please enter appropriate numeric value ");

                }
            }
            return intStudents;
            
           
        }

        public static int HowManyScores()
        {

            string  strScores;
            int intScores;

            Write(" How many tests have you administered to each of your students?  ");

            strScores = " " + ReadLine();

            if (int.TryParse(strScores, out intScores) == false)
            {
                WriteLine("Please enter appropriatenumeric value ");
                Write(" How many tests have you administered to each of your students?  ");
                strScores = " " + ReadLine();

                if (int.TryParse(strScores, out intScores) == false)
                {
                    WriteLine("Please enter appropriatenumeric value ");

                }

            }
            return intScores;
        }

        public static void  CalcTotal_G (double[,] gradeArray)
        {
            
            double[] TotalpPerStu = new double[gradeArray.Length];
            double sum = 0;
            string grade = "";


            for (int st = 0; st < gradeArray.GetLength(0); st++)
            {
                for (int sc = 0; sc < gradeArray.GetLength(1); sc++)
                {
                    string strInput;

                    WriteLine(" Enter score # {0} for student #{1}", sc + 1, st + 1);
                    strInput = ReadLine();


                    if (double.TryParse(strInput, out gradeArray[st, sc]) == false)
                    {
                        WriteLine("Please enter valid numeric value");
                    }

                    sum += gradeArray[st, sc];



                }
                if (sum > 100 || sum < 0)

                    grade = "Error";

                else if (sum > 94)

                    grade = "A+";

                else if (sum > 90)

                    grade = "A";

                else if (sum > 85)

                    grade = "B+";

                else if (sum > 80)

                    grade = "B";

                else if (sum > 70)

                    grade = "C+";

                else if (sum > 60)

                    grade = "C";

                else if (sum > 30)

                    grade = "D";

                else

                    grade = "F";
                Write(" Student Number {0}\t score: {1}\tGrade: {2}\n", st + 1, sum, grade);
                
                sum = 0;
            }
           
        }

       
        }
}
