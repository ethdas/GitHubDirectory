﻿
/* Name :  Daniel  Neway
 * Course  Name  : CIS162AD
 * Section  Number  : 12130
  */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace C_Sharp_TextBook
{
    class Program
    {/// <summary>
    /// The purpose of this application is to display 
    /// a banner containing information about the Title ,
    /// the edition number and the auther of the text book
    /// we are using to study C# 162AD
    /// </summary>
    /// <param name="args"> we are not using any arguments here</param>
        static void Main(string[] args)
        {
            // upper boarder of the banner 
            Console.WriteLine("**************************************************");
            // a white space 
            Console.WriteLine("**                                              **"); 
            // next two methods show Title 
            Console.WriteLine("**                C# PROMMING:                  **");
            Console.WriteLine("**    From Problem Analysis to Program Design   **");
            //a separation line 
            Console.WriteLine("**              __________________              **");
            // a white space
            Console.WriteLine("**                                              **");
            //The book edition
            Console.WriteLine("**                FIVTH EDITION                 **");
            //lower separation line
            Console.WriteLine("**             __________________               **");
            // white space
            Console.WriteLine("**                                              **");
            // the auther of the book
            Console.WriteLine("**               BARBARA DOYLE                  **");
            //another white space
            Console.WriteLine("**                                              **");
            // lower boarder of the banner
            Console.WriteLine("**************************************************");
            //to keep the banner on display until user strikes a key board
            Console.ReadKey();
        }
    }
}
