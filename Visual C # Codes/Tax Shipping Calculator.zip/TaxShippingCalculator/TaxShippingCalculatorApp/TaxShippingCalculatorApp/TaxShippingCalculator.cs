﻿//TaxShippingCalculator
//--------------------
//OrderNumber: string
//orderAmt: decimal
//state : string
//        + SubTota(): decimal
//        + SetTaxAmount():decimal
//        +SetShippingAmount():decimal
//        +GrandTotal():decimal
//        +ToString(): string
//-------------------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxShippingCalculatorApp
{
    class TaxShippingCalculator
    {

        private const decimal SHIPPING_UNDER_50 = 12.99M;
        private const decimal SHIPPING_UNDER_100= 4.99M;
        private const decimal SHIPPIN_OVER_100 = 0.00M;
        private const double TAX_CALIFORNIA = 0.10D;
        private const double TAX_ARIZONA = 0.05D;
        private const double TAX_OTHER_STATES = 0.00D;
        private string orderNumber;
        private decimal orderAmount;
        private string state;

        public TaxShippingCalculator()
        {

        }
        public TaxShippingCalculator(string oNumber , decimal amount , string oState)
        {
            orderNumber = oNumber;
            orderAmount = amount;
            state = oState;

        }
        public TaxShippingCalculator(string oNumber, decimal amount)
        {
            orderNumber = oNumber;
            orderAmount = amount;
          
        }

        public string OrderNumber
        {
            get
            {
                return orderNumber;
            }
        }

        public decimal OrderAmount
        {
            get
            {
                return orderAmount;
            }

            set
            {
                orderAmount = value;
            }
            
        }
        public string State
        {
            get
            {
                return state;
            }
        }

        public decimal SubTotal()
        {
            return OrderAmount;
        }


        public decimal SetTaxAmt()
        {
            string orderState = State;
            decimal decTax = 0.0M;
            switch (orderState)
            {
                case "AZ":
                case "az":
                case "aZ":
                case "Az":
                    decTax = SubTotal() * Convert.ToDecimal(TAX_ARIZONA);
                    break;
                case "CA":
                case "ca":
                case "cA":
                case "Ca":
                    decTax = SubTotal() * Convert.ToDecimal(TAX_CALIFORNIA);
                    break;
                case "OTH":
                case "oth":
                case "other":
                    decTax = SubTotal() * Convert.ToDecimal(TAX_OTHER_STATES);
                    break;
            }
            return decTax;
        }

        public decimal SetShippingAmount()
        {
            decimal orderAmt;
            orderAmt= OrderAmount;
            decimal shippingRate=0.00M;

            if (orderAmt < 50)
                shippingRate = SHIPPING_UNDER_50;
            else if (orderAmt < 100)
                shippingRate = SHIPPING_UNDER_100;
            else if (orderAmt > 100)
                shippingRate = SHIPPIN_OVER_100;

            return shippingRate;
        }

        public decimal GrandTotal()
        {
            decimal gTotal;
            gTotal = SubTotal() + SetTaxAmt() + SetShippingAmount();
            return gTotal;
        }

        public override string ToString()
        {
            return "\tTax and Shipping Calculator App  " +
                "\nState: " + State +
                "\n\nOrder Number: " + OrderNumber +
                "\nOrder Amount :  " + SubTotal() +
                "\nTax : " + SetTaxAmt() +
                "n\nGrand Total: " + GrandTotal();

        }
    }
}
