﻿
//TaxShippingCalculatorApp
//--------------------
//OrderNumber: string
//orderAmt: decimal
//state : string
//        +InputOrderNumber(): string
//        +InputState() :string
//        +InputTotalOrderAmt: decimal
//----------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace TaxShippingCalculatorApp
{
    class TaxShippingCalculatorApp
    {
        static void Main(string[] args)
        {
            string orderNumber = InputOrderNumber();
            decimal orderAmt= InputTotalOrderAmt();
            string state= InputState();

            TaxShippingCalculator TaxAndShippingForABC = new TaxShippingCalculator(orderNumber, orderAmt, state);
            Write(TaxAndShippingForABC);
            ReadKey();

        }

        public static string InputOrderNumber()
        {
            string ordrNumber;
            Write("Please enter order number: ");
            ordrNumber = ReadLine();
            return ordrNumber;
        }

        public static string InputState()
        {
            string strStateInput;
           
            Write("Please enter the state where order came from:" +
                "\t\nput 'AZ' if from Arizona ," + 
                "\n'CA' if from California and" +
                "\n'OTH' if from other states ");
            strStateInput = ReadLine();
                     
            return strStateInput;
          
        }

        public static decimal InputTotalOrderAmt()
        {
            decimal decOrderInput;
            string strOrderInput;
           
            Write("Please enter total amount for sporting Equipment ordered: ");
            strOrderInput = ReadLine();
            
            decimal.TryParse(strOrderInput, out decOrderInput);
               
                return decOrderInput;
                  

        }
    }
}
    