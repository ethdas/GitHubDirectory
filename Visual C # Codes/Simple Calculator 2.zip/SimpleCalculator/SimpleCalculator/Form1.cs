﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
       int one;
        int Two;
       int Result;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                one = int.Parse(txtOne.Text);
                Two = int.Parse(txtTwo.Text);
                Result = one + Two;
                lblResult.Text = Result.ToString();
            }
            catch (FormatException x)
            {
                MessageBox.Show("Whooa!! , look what you have done ", x.Message);

            }

            catch (DivideByZeroException x)
            {
                MessageBox.Show("Noooo!! , look what you have done ", x.Message);
            }

            catch (ArithmeticException x)
            {
                MessageBox.Show("No No !! , look what you have done ", x.Message);
            }

            catch (Exception x)
            {
                MessageBox.Show("Not Good!! , look what you have done ", x.Message);
            }
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            try
            {
                one = int.Parse(txtOne.Text);
                Two = int.Parse(txtTwo.Text);
                Result = one - Two;
                lblResult.Text = Result.ToString();
            }
            catch (FormatException x)
            {
                MessageBox.Show("Whooa!! , look what you have done ", x.Message);

            }

            catch (DivideByZeroException x)
            {
                MessageBox.Show("Noooo!! , look what you have done ", x.Message);
            }

            catch (ArithmeticException x)
            {
                MessageBox.Show("No No !! , look what you have done ", x.Message);
            }

            catch (Exception x)
            {
                MessageBox.Show("Not Good!! , look what you have done ", x.Message);
            }
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {

            try
            {
                one = int.Parse(txtOne.Text);
                Two = int.Parse(txtTwo.Text);
                Result = one / Two;
                lblResult.Text = Result.ToString();
            }
            catch(FormatException x)
            {
                MessageBox.Show("Whooa!! , look what you have done ", x.Message);
                
            }

            catch (DivideByZeroException x)
            {
                MessageBox.Show("Noooo!! , look what you have done ", x.Message);
            }

            catch (ArithmeticException x)
            {
                MessageBox.Show("No No !! , look what you have done ", x.Message);
            }

            catch (Exception x)
            {
                MessageBox.Show("Not Good!! , look what you have done ", x.Message);
            }
          
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {

            try
            {
                one = int.Parse(txtOne.Text);
                Two = int.Parse(txtTwo.Text);
                Result = one * Two;
                lblResult.Text = Result.ToString();
            }
            catch (FormatException x)
            {
                MessageBox.Show("Whooa!! , look what you have done ", x.Message);

            }

            catch (DivideByZeroException x)
            {
                MessageBox.Show("Noooo!! , look what you have done ", x.Message);
            }

            catch (ArithmeticException x)
            {
                MessageBox.Show("No No !! , look what you have done ", x.Message);
            }

            catch (Exception x)
            {
                MessageBox.Show("Not Good!! , look what you have done ", x.Message);
            }
        }
    }
}
