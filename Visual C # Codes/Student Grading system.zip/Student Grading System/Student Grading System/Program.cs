﻿/*
 *  Name : Daniel Neway
 *  Application: Letter Grading system
 *  Purpose: a program to help instructors calculate grades for students. 
 *          First prompt instructors to enter the desired number of scores.
 *          This value is the size of your array (you can use an array of type int for this assignment).
 *          Then, use a loop to prompt the instructors to enter the scores (from 0 to 100).
 *          You must store each score in this array. Once the users have entered all scores, 
 *          use a loop to calculate the grade for each student in the course and the corresponding letter grade.
 *          Finally,Output the final grade and corresponding letter grade.
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Student_Grading_System
{
    class Program
    {
        static void Main(string[] args)
        {

            string strScoreSize;//to hold prompt value
            int intScoreSize; // to hold the converted value
            string strScoreValue; // to hold student scores
            string grade; // to out put grade

            Write(" How many scores will you enter?  ");
            strScoreSize = " " +  ReadLine();

            if (int.TryParse(strScoreSize, out intScoreSize) == false)
            {
                WriteLine(" Ya, this message does NOT show ");
                
            }
            

            int[] scoreValue = new int[intScoreSize];

            for (int i = 0; i < scoreValue.Length; i++)
            {
                Write(" Enter Score {0} : ", i + 1);
                strScoreValue = " " +ReadLine();

                if (int.TryParse(strScoreValue, out scoreValue[i]) == false)
                {

                    WriteLine(" Error ! Your score is 0");
                }

                if (scoreValue[i] > 100 || scoreValue[i] < 0 )
                {
                    WriteLine(" Error grade!");
                                   
                                    }
            }

            for (int i = 0; i < scoreValue.Length; i++)

            {

                if (scoreValue[i] > 100 || scoreValue[i] < 0)

                    grade = "Error";

                else if (scoreValue[i] > 94)

                    grade = "A+";

                else if (scoreValue[i] > 90)

                    grade = "A";

                else if (scoreValue[i] > 85)

                    grade = "B+";

                else if (scoreValue[i] > 80)

                    grade = "B";

                else if (scoreValue[i] > 70)

                    grade = "C+";

                else if (scoreValue[i] >60)

                    grade = "C";

                else if (scoreValue[i] >30)

                    grade = "D";

                else

                    grade = "F";

              Write("{0}\t{1}\t{2}\n", i + 1, scoreValue[i], grade);
               ReadKey();

            }
        }
    }
}
