﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeePayCalculator
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            double hR;
            while (double.TryParse(txtHourlyRate.Text, out hR) == false)


            {
                MessageBox.Show("Something is wrong ! Numeric Value should be entered ");
                break;

            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            double hW;
            while (double.TryParse(txtHoursWorked.Text, out hW) == false)
            {
                MessageBox.Show("Something is wrong ! Numeric Value should be entered ");

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            
            
            
           

            PayCalc NextEmployee = new PayCalc();
            

            int row = 0;
            dgvEmp.Rows.Add();
            row = dgvEmp.Rows.Count - 2;
            NextEmployee.HourlyRate = Convert.ToDouble(txtHourlyRate.Text);
            NextEmployee.HoursWorked= Convert.ToDouble(txtHoursWorked.Text);

            dgvEmp["FullName", row].Value = txtFullName.Text;
            dgvEmp["HourlyRate", row].Value = txtHourlyRate.Text;
            dgvEmp["HoursWorked", row].Value = txtHoursWorked.Text;

            dgvEmp["GrossPay", row].Value = NextEmployee.DetermineGrossPay();
            dgvEmp["Federal", row].Value = NextEmployee.DetermineFederalTax();
            dgvEmp["State", row].Value = NextEmployee.DetermineStateTax();
            dgvEmp["SS", row].Value = NextEmployee.DetermineSocialSecurity();

            dgvEmp["Medicare", row].Value = NextEmployee.DetermineMedicare();
            dgvEmp["Net", row].Value = NextEmployee.DetermineNetPay();
            





        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

      

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            double TotalHours = 0;
            double TotalGross = 0;
            double TotalNet = 0;
            double TotalSS = 0;
            double TotalMedicare = 0;
            double TotalStateTax = 0;
            double TotalFederalTax = 0;
            dgvEmp.AllowUserToAddRows = false;

            for( int i =0; i<= dgvEmp.RowCount-1; i++)
            {
                TotalHours = TotalHours + double.Parse(dgvEmp.Rows[i].Cells[2].Value.ToString());
                TotalGross = TotalGross + double.Parse(dgvEmp.Rows[i].Cells[3].Value.ToString());
                TotalNet = TotalNet + double.Parse(dgvEmp.Rows[i].Cells[4].Value.ToString());
                TotalSS = TotalSS + double.Parse(dgvEmp.Rows[i].Cells[5].Value.ToString());
                TotalMedicare = TotalMedicare + double.Parse(dgvEmp.Rows[i].Cells[6].Value.ToString());
                TotalStateTax = TotalStateTax + double.Parse(dgvEmp.Rows[i].Cells[7].Value.ToString());
                TotalFederalTax = TotalFederalTax + double.Parse(dgvEmp.Rows[i].Cells[8].Value.ToString());
            }
            lbltotal.Text = "All Employee Total for the Current Pay Period" +
                "\n**********************************************" +
                
                "\nTotal Hours Worked:    " + TotalHours.ToString() +
               
                "\nTotal Gross Pay:     " +TotalGross.ToString("C") +
               
                "\nTotal Net Pay:        " + TotalSS.ToString("C") +
                
                "\nTotal Social Security Withheld:      " + TotalMedicare.ToString("C") +
                
                "\nTotal Medicare Withheld:     " + TotalMedicare.ToString("C") +
                
                "\nTotal State Tax Withheld:        " + TotalStateTax.ToString("C") +
               
                "\nTotal Federal Tax Withheld:      " + TotalFederalTax.ToString("C") ;
        }
    }
}
