﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeePayCalculator
{
    public class PayCalc
    {
        private string fullName;      
        private double hourlyRate;
        private double  hoursWorked;
        // default Constructor
        public PayCalc()
        {

        }
        public PayCalc(string Name, double Rate, double Hours)
        {

            fullName = Name;
            hourlyRate = Rate;
            hoursWorked = Hours;
        }


        // Property used to access or change 
        public string FullName
        {
            set
            {
                fullName = value;
            }
            get
            {
                return fullName;
            }
       
        }
        public double HourlyRate
        {
            set
            {
                hourlyRate = value;
            }
            get
            {
                return hourlyRate;
            }

        }
        public double HoursWorked
        {
            set
            {
                hoursWorked = value;
            }
            get
            {
                return hoursWorked;
            }

        }

        public double DetermineGrossPay()
        {
            return hourlyRate * hoursWorked;
        }

        public double DetermineFederalTax()
        {
            const double FEDERAL_Tax = 0.25;
            return DetermineGrossPay() * FEDERAL_Tax;
        }

        public double DetermineStateTax()
        {
            const double STATE_TAX = 0.06;
            return DetermineGrossPay() * STATE_TAX;
        }
        public double DetermineSocialSecurity()
        {
            const double SOCIAL_SECURITY = 0.062;
            return DetermineGrossPay() * SOCIAL_SECURITY;
        }
        public double DetermineMedicare()
        {
            const double MEDICARE= 0.0145;
            return DetermineGrossPay() * MEDICARE;
        }
        public double DetermineNetPay()
        {
            double deduction;
            deduction = (DetermineFederalTax() +
                DetermineStateTax() +
                DetermineSocialSecurity() +
                DetermineMedicare());

            return DetermineGrossPay()-deduction;
        }

       
    }

}
