﻿/*Name : Daniel Neway
 * Lesson : 4
 * Course : C# CIS162AD
 * Purpose: Write a program that takes inches in as input and converts them to Feet,Yards,and Miles
 */

using System;
using static System.Console;

namespace FromInchesTo
{
    class Program
    {
        static void Main(string[] args)
        {
            InitialInstruction();
           
            CollectConvertDisplay();
          
        }


        // introduce the application and instruct user what to do
        static void InitialInstruction()
        {
            WriteLine();
            WriteLine();
            WriteLine("         This program converts value given in inches to feet , yards and Miles");
            WriteLine("         :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
            WriteLine("         Please enter a value in inches below:  ");
            WriteLine();
        }


        //Collects user input in string format , convert it to numeric format and display result
        static void CollectConvertDisplay()
        {
            string userInput;
            double convertedInput;
            userInput = ReadLine();
            convertedInput = double.Parse(userInput);
            double toFeet = GetFeet(convertedInput);
            double toYards = GetYards(convertedInput);
            double toMiles = GetMiles(convertedInput);
            WriteLine("         ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
            WriteLine("         {0} converted into feet , yards and miles would be : ", convertedInput);
            WriteLine("         ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
            WriteLine();
            WriteLine("                 {0:n2} feet", GetFeet(convertedInput));
            WriteLine("                 {0:n2} Yards", toYards);
            WriteLine("                 {0:n2} Miles", toMiles);
            WriteLine("             <><><><><><><><><><>");
            ReadLine();

        }
       
       

        // accepts an input(given in inches) and converts it to feet
        static double GetFeet(double convertedInput)
        {
            const double CONVERTER_TO_FEET = 12;
            return convertedInput / CONVERTER_TO_FEET;
        }


        // accepts an input(given in inches) and converts it to Yards
        static double GetYards(double convertedInput)
        {
            const double CONVERTER_TO_YARDS = 36;
            return convertedInput / CONVERTER_TO_YARDS;
        }


        // accepts an input(given in inches) and converts it to Miles
        static double GetMiles(double convertedInput)
        {
            const double CONVERTER_TO_MILES = 63360;
            return convertedInput / CONVERTER_TO_MILES;
        }
    }
}
