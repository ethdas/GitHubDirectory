﻿Module Calculate




    Public PrintBooksPrice() As Double = {11.95, 14.5, 29.95, 18.5}
    Public AudioBooksPrice() As Double = {29.95, 14.5, 12.95, 11.5}
    Public strPrint() As String = {"I did it Your Way", "The History Of Scotland",
    "Learn Calculus In One Day", "Feel the Stress"}
    Public strAudio() As String = {"Learn Calculus in One Way", "The History of Scotland",
    "The Science of Body Language", "Relaxation Technique"}









End Module
